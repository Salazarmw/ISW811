<div class="sm:col-span-4">
    <?php echo e($slot); ?>

</div>
<?php /**PATH /vagrant/sites/30days.isw811.xyz/resources/views/components/form-field.blade.php ENDPATH**/ ?>