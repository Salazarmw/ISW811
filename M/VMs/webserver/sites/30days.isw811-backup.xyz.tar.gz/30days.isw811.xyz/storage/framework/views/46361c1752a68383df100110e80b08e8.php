<label
    <?php echo e($attributes->merge(['class' => 'block text-sm font-medium leading-6 text-gray-900'])); ?>><?php echo e($slot); ?></label>
<?php /**PATH /vagrant/sites/30days.isw811.xyz/resources/views/components/form-label.blade.php ENDPATH**/ ?>