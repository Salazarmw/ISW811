# 30 Days to Learn Laravel

## 🎬 Episodio 02 - Your First Route and View

En este episodio primero editamos la vista `welcome.blade.php` para mostrar un mensaje de bienvenida personalizado. Luego, creamos una nueva ruta en `web.php` que devuelve una vista llamada `about`. Finalmente, configuramos el archivo `.env` para establecer el nombre de la aplicación.

De esta manera se crea una ruta que responde con un vista de PHP.

```php
Route::get('/about', function () {
    return view('about');
});
```

De esta manera se retorna una respuesta de tipo JSON desde una ruta de Laravel.

```php
Route::get('/json', function () {
    return ['foo' => 'bar', 'baz' => 'qux'];
});
```

Las vistas en Laravel se almacenan en el directorio `resources/views`.

## 🎬 Episodio 03 - Create a Layout File Using Laravel Components

Los componentes en Laravel se almacenan en el directorio `resources/views/components`.

Y la forma de utilizar un componente es la siguiente:

```php
<x-layout>
    <h1>Hello from the Home Page.</h1>
</x-layout>
```

## 🎬 Episodio 04 - Make a Pretty Layout Using TailwindCSS

En este episodio se implementó una mejora visual utilizando **TailwindCSS** y se reorganizó el diseño principal de la aplicación mediante **componentes reutilizables** y **slots dinámicos** de Blade.

### ✅ Cambios clave:

Se creó un componente `NavLink` reutilizable para los enlaces de navegación

```blade
<a {{ $attributes }}>
    {{ $slot }}
</a>
```

Se reemplazó el contenido estático por Blade Slots para hacer el diseño más flexible

```blade
<!-- En el layout -->
<x-slot name="heading">
    {{ $heading }}
</x-slot>

{{ $slot }}
```

Ejemplo de uso en una vista

```blade
<x-layout>
    <x-slot name="heading">Home Page</x-slot>

    <p>Bienvenido a la página de inicio.</p>
</x-layout>
```

## 🎬 Episodio 05 - Style the Currently Active Navigation Link

En este episodio se implementó un sistema para resaltar visualmente el enlace activo en la navegación, usando Blade, TailwindCSS y componentes personalizados.

### ✅ Cambios clave:

Se aplicó estilo **condicional** a los enlaces de navegación según la ruta actual, utilizando el helper `request()->is()` y se cambio la lógica dentro del componente NavLink, utilizando props para hacerlo más limpio y reutilizable

```blade
@props(['active' => false])

<a {{ $attributes->merge([
    'class' => $active
        ? 'bg-gray-900 text-white'
        : 'text-gray-300 hover:bg-gray-700 hover:text-white'
]) }}>
    {{ $slot }}
</a>
```

Se usa el componente indicando si está activo de la siguiente manera

```blade
<x-navlink href="/" :active="request()->is('/')">Home</x-navlink>
<x-navlink href="/about" :active="request()->is('about')">About</x-navlink>
<x-navlink href="/contact" :active="request()->is('contact')">Contact</x-navlink>
```

## 🎬 Episodio 06 - View Data and Route Wildcards

En este episodio se aprendió a **pasar datos desde las rutas a las vistas** y usar **parámetros dinámicos en rutas**

### ✅ Cambios clave:

Se pasaron datos a vistas desde rutas utilizando el helper view()

```php
Route::get('/', function () {
    return view('home', [
        'greeting' => 'Hello',
        'name' => 'Larry Robot',
    ]);
});
```

Ejemplo de vista que recibe los datos

```blade
<h1>{{ $greeting }}, {{ $name }}!</h1>
```

Tambien pasamos y recorrimos arreglos usando Blade y @foreach

```php
Route::get('/jobs', function () {
    return view('jobs', [
        'jobs' => [
            ['id' => 1, 'title' => 'Director', 'salary' => 50000],
            ['id' => 2, 'title' => 'Programmer', 'salary' => 10000],
            ['id' => 3, 'title' => 'Teacher', 'salary' => 40000],
        ],
    ]);
});
```

Ejemplo de vista que muestra los trabajos

```blade
<ul>
@foreach ($jobs as $job)
    <li>
        <a href="/jobs/{{ $job['id'] }}" class="text-blue-500 hover:underline">
            {{ $job['title'] }}
        </a>: <strong>${{ $job['salary'] }}</strong> per year
    </li>
@endforeach
</ul>
```

Y finalmente, se implementó una ruta con un parámetro dinámico para mostrar detalles de un trabajo específico

```php
Route::get('/jobs/{id}', function ($id) {
    $jobs = [
        ['id' => 1, 'title' => 'Director', 'salary' => 50000],
        ['id' => 2, 'title' => 'Programmer', 'salary' => 10000],
        ['id' => 3, 'title' => 'Teacher', 'salary' => 40000],
    ];

    $job = collect($jobs)->first(fn ($job) => $job['id'] == $id);

    if (! $job) {
        abort(404);
    }

    return view('job', ['job' => $job]);
});
```

Ejemplo de vista que muestra los detalles del trabajo

```blade
<!-- job.blade.php -->
<h2 class="text-lg font-bold">{{ $job['title'] }}</h2>
<p>This job pays ${{ $job['salary'] }} per year.</p>
```

## 🎬 Episodio 07 - Autoloading, Namespaces, and Models

En este episodio se abordó la **duplicación de datos** en las rutas y se introdujo el uso de **modelos en Laravel**, aplicando principios de **MVC** y buenas prácticas de organización de código.

### ✅ Cambios clave:

Se movió el arreglo de trabajos a un modelo centralizado llamado `Job` para evitar repetir datos en múltiples rutas.

```php
namespace App\Models;

class Job
{
    public static function all(): array
    {
        return [
            ['id' => 1, 'title' => 'Director', 'salary' => 50000],
            ['id' => 2, 'title' => 'Programmer', 'salary' => 10000],
            ['id' => 3, 'title' => 'Teacher', 'salary' => 40000],
        ];
    }
}
```

Se agrego el método find() en el modelo para encapsular la lógica de búsqueda por ID y reutilizarla fácilmente

```php
use Illuminate\Support\Arr;

public static function find(int $id): ?array
{
    return Arr::first(self::all(), fn ($job) => $job['id'] === $id);
}
```

Se actualizaron las rutas para usar el modelo `Job` en lugar de arreglos duplicados

```php
use App\Models\Job;

Route::get('/jobs', function () {
    return view('jobs', [
        'jobs' => Job::all(),
    ]);
});

Route::get('/jobs/{id}', function ($id) {
    $job = Job::find($id);

    if (! $job) {
        abort(404);
    }

    return view('job', ['job' => $job]);
});
```

Se implementó el manejo de errores si no se encuentra el trabajo, se lanza un abort(404) para mostrar una página de error amigable

## 🎬 Episodio 08 - Database Setup and Migrations

En este episodio se dio el paso crucial de dejar atrás los datos "hardcodeados" y comenzar a utilizar una **base de datos real** con Laravel y migraciones.

### ✅ Cambios clave:

-   **Configuración de base de datos:**
    -   Laravel por defecto usa **SQLite**, ideal para desarrollo local.
    -   Se configuró en el archivo `.env` para apuntar a `database/database.sqlite`:

```env
DB_CONNECTION=sqlite
DB_DATABASE=/ruta/absoluta/a/database/database.sqlite
```

-   Usamos Artisan para gestionar la base de datos

```bash
php artisan migrate              # Ejecuta todas las migraciones pendientes
php artisan migrate:rollback     # Revierte el último lote
php artisan migrate:refresh      # Revierte y vuelve a ejecutar todas
```

Se creo una migración personalizada

```bash
php artisan make:migration create_job_listings_table
```

Luego hay que editar el archivo generado en `database/migrations/` para definir la estructura de la tabla `job_listings`.

```php
public function up(): void
{
    Schema::create('job_listings', function (Blueprint $table) {
        $table->id();
        $table->string('title');
        $table->integer('salary');
        $table->timestamps();
    });
}
```

Y finalmente, se ejecuta la migración para crear la tabla en la base de datos

```bash
php artisan migrate
```

## 🎬 Episodio 09 - Meet Eloquent

En este episodio se introdujo **Eloquent**, el ORM (Object-Relational Mapper) de Laravel, que permite interactuar con la base de datos mediante objetos en lugar de consultas SQL directas.

### ✅ Cambios clave:

-   ✅ **Conversión del modelo Job a un modelo Eloquent**:
    -   Se eliminó el arreglo hardcoded.
    -   El modelo ahora extiende `Illuminate\Database\Eloquent\Model`:

```php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Job extends Model
{
    protected $fillable = ['title', 'salary'];
    // Si la tabla no sigue la convención (jobs), especificarla:
    // protected $table = 'job_listings';
}
```

## 🎬 Episodio 10 - Model Factories

En este episodio se exploró el uso de **factories en Laravel**, una herramienta clave para generar datos falsos rápidamente en entornos de desarrollo y pruebas.

### ✅ Cambios clave:

-   ✅ **Uso de Factory en Tinker**:

```bash
php artisan tinker
>>> User::factory()->create();                 // Crea un usuario falso
>>> User::factory()->count(100)->create();    // Crea 100 usuarios falsos
>>> User::factory()->unverified()->create();  // Crea un usuario sin verificar
```

-   ✅ **Creación de una Factory personalizada**:

```bash
php artisan make:factory JobFactory --model=Job
```

```php
public function definition()
{
    return [
        'title' => $this->faker->jobTitle(),
        'salary' => $this->faker->numberBetween(30000, 100000),
    ];
}
```

Vimos la relaciones en factories. Si un modelo Job pertenece a un Employer, puedes generar esa relación automáticamente:

```php
'employer_id' => \App\Models\Employer::factory(),
```

## 🎬 Episodio 11 - Two Key Eloquent Relationship Types

En este episodio se exploraron dos tipos fundamentales de relaciones en Eloquent: `belongsTo` y `hasMany`, que permiten expresar conexiones entre modelos de forma sencilla y poderosa.

### ✅ Cambios clave:

#### 🔁 Definir que un trabajo pertenece a un empleador

En el modelo `Job`, se definió un método que representa esta relación:

```php
public function employer()
{
    return $this->belongsTo(Employer::class);
}
```

Esto le indica a Laravel que cada trabajo tiene un `employer_id` que referencia al modelo `Employer`.

🔄 Relación inversa: un empleador tiene muchos trabajos

En el modelo `Employer`, se definió la relación inversa:

```php
public function jobs()
{
    return $this->hasMany(Job::class);
}
```

Esto le indica a Laravel que cada empleador puede tener múltiples trabajos asociados.

Ahora es posible acceder a todos los trabajos de un empleador:

```php
$employer = App\Models\Employer::first();
$jobs = $employer->jobs;
```

Y también acceder al empleador desde un trabajo:

```php
$job = App\Models\Job::first();
$employer = $job->employer;
```

## 🎬 Episodio 12 - Pivot Tables and BelongsToMany Relationships

En este episodio se implementa una relación de muchos a muchos entre los modelos `Job` y `Tag` usando una **tabla pivote** y la relación `belongsToMany` de Eloquent.

---

### ✅ Cambios clave:

#### 🧱 Crear el modelo Tag, su migración y su factory

```bash
php artisan make:model Tag -mf
```

#### 🔗 Crear la tabla pivote job_tag

Para conectar trabajos (`job_listings`) con etiquetas (`tags`), se creó una tabla pivote llamada job_tag, siguiendo la convención de usar los nombres en singular y orden alfabético.

La migración se define así:

```php
$table->foreignId('job_listing_id')->constrained()->cascadeOnDelete();
$table->foreignId('tag_id')->constrained()->cascadeOnDelete();
$table->timestamps();
```

##### 🔒 Claves foráneas y eliminación en cascada

Se configuraron las claves foráneas con `cascadeOnDelete()` para que, al eliminar un trabajo o una etiqueta, también se eliminen los registros relacionados en la tabla pivote y evitar registros huérfanos.

#### 🔁 Definir la relación belongsToMany

En el modelo `Job`:

```php
public function tags()
{
    return $this->belongsToMany(Tag::class, 'job_tag', 'job_listing_id', 'tag_id');
}
```

En el modelo `Tag`:

```php
public function jobs()
{
    return $this->belongsToMany(Job::class, 'job_tag', 'tag_id', 'job_listing_id');
}
```

## Episodio 13 - Pivot Tables and BelongsToMany Relationships

### 🧠 Resumen del Episodio

En el día trece, abordamos el **problema N+1 en relaciones Eloquent** y aprendemos a **optimizar las consultas a la base de datos** usando **eager loading**.

---

### ✅ Cambios clave:

#### 🛠️ Mejorando la Vista de Listado de Trabajos

-   Se actualiza la vista de empleos para mostrar cada uno como una **tarjeta clickeable** (`<a>`), utilizando utilidades de **Tailwind CSS**.
-   Se añade **estética mejorada**: padding, bordes, espaciado entre tarjetas y bordes redondeados.
-   Se muestra el **nombre del empleador** accediendo a la relación `employer` en el modelo `Job`.

---

#### 🧩 ¿Qué es el Problema N+1?

El **problema N+1** sucede cuando:

-   Se realiza una **consulta inicial (N)** para obtener los registros principales.
-   Luego, se ejecuta **una consulta adicional por cada relación asociada**, resultando en **muchas consultas innecesarias**.

📉 Por ejemplo:

```php
$jobs = Job::all();
foreach ($jobs as $job) {
    echo $job->employer->name;
}
```

-   Esto ejecuta 1 consulta para los jobs y N consultas para employers.

---

#### 🔍 Cómo Detectar el Problema N+1

Con la herramienta Laravel Debugbar para ver todas las consultas SQL:

```bash
composer require barryvdh/laravel-debugbar --dev
```

---

#### 🚀 Solución: Eager Loading

La carga anticipada (eager loading) permite consultar todas las relaciones necesarias en una sola consulta:

```php
$jobs = Job::with('employer')->get();
```

-   ✅ Esto ejecuta solo 2 consultas: una para jobs y otra para employers, sin importar la cantidad de registros.

## Episodio 14 - All You Need to Know About Pagination

### 🎯 Resumen del Episodio

En este episodio se explora cómo Laravel facilita la **paginación**, una técnica clave para manejar grandes volúmenes de datos sin afectar el rendimiento.

---

### ✅ Cambios clave:

#### 🛠️ Implementación de paginación

Utiliza el método `paginate()` en tu consulta:

```php
$jobs = Job::with('employer')->paginate(3); // 3 empleos por página
```

---

#### 🖥️ Mostrar enlaces de paginación en Blade

En tu vista Blade, usa:

```blade
{{ $jobs->links() }}
```

Laravel usa estilos de Tailwind CSS por defecto para estos enlaces.

---

#### 🎨 Personalización de las vistas de paginación

Para cambiar el HTML de los controles de paginación:

```bash
php artisan vendor:publish --tag=laravel-pagination
```

Esto copiará las vistas en:

```swift
resources/views/vendor/pagination/
```

---

#### 🧩 Cambiar el framework CSS para la paginación

Por ejemplo, para usar Bootstrap 5, agrega lo siguiente en `App\Providers\AppServiceProvider.php`:

```php
use Illuminate\Pagination\Paginator;

public function boot()
{
    Paginator::useBootstrapFive();
}
```

---

#### 🔄 Tipos de paginación

Paginación estándar (default): con números de página y enlaces de navegación.

```php
Job::with('employer')->paginate(3);
```

Paginación simple: solo “Anterior” y “Siguiente”.

```php
Job::with('employer')->simplePaginate(3);
```

Paginación por cursor: usa un cursor codificado, ideal para grandes cantidades de datos.

```php
Job::with('employer')->cursorPaginate(3);
```

## Episodio 15 - Understanding Database Seeders

### 📝 Resumen del Episodio

En este episodio se explora el concepto de **database seeding** en Laravel, una técnica para poblar automáticamente la base de datos con datos de prueba o iniciales.

---

### ✅ Cambios clave:

#### 🛠️ Seeders en Laravel

-   Se encuentran en el directorio: `database/seeders`.
-   Laravel incluye por defecto la clase `DatabaseSeeder`, que actúa como punto de entrada para ejecutar múltiples seeders.

**Ejecutar los seeders:**

```bash
php artisan db:seed
```

---

#### 🚀 Migrar y seedear al mismo tiempo

Puedes recrear y poblar la base de datos con un solo comando:

```bash
php artisan migrate:fresh --seed
```

---

#### 🏭 Uso de Factories en Seeders

Para generar grandes cantidades de datos falsos de forma rápida:

```php
\App\Models\Job::factory(200)->create();
```

-   Esto crea 200 registros en la tabla jobs utilizando la definición del factory.

---

#### 📂 Dividir Seeders para Mayor Flexibilidad

Se pueden crear múltiples seeders para poblar partes específicas de la base de datos:

```bash
php artisan make:seeder JobSeeder
```

-   Ejemplo en DatabaseSeeder:

```php
public function run()
{
    $this->call([
        UserSeeder::class,
        JobSeeder::class,
    ]);
}
```

## Episodio 16 - Forms and CSRF Explained (with Examples)

### 🎯 Resumen del Episodio

En este episodio se abordan los formularios en Laravel, incluyendo el manejo de datos del request, organización de carpetas para vistas y protección contra ataques CSRF.

---

### ✅ Cambios clave:

#### 🚦 Definir Rutas para Formularios

-   Para crear un nuevo trabajo, la ruta debe ser: `/jobs/create`.
-   **Importante**: Las rutas con comodines como `jobs/{id}` deben ir **después** de las rutas específicas como `jobs/create` para evitar conflictos.

---

#### 🗂 Organización de Vistas

Se agruparon las vistas relacionadas en carpetas, por ejemplo, dentro de `/resources/views/jobs/`.

Convenciones para nombres de vistas:

-   `index.blade.php`: Listado de trabajos.
-   `show.blade.php`: Detalles de un solo trabajo.
-   `create.blade.php`: Formulario para crear un trabajo.

En el controlador o rutas se hace referencia así:

```php
return view('jobs.create');
```

---

#### 📥 Envío del Formulario

-   Constuir un formulario HTML para crear un trabajo.

-   Cambia el método del formulario a POST.

-   Establece la acción hacia /jobs.

```html
<form method="POST" action="/jobs">
    @csrf
    <!-- campos del formulario -->
</form>
```

-   Crea una ruta POST /jobs en web.php para procesar el formulario.

---

#### 🛡 Protección CSRF

Laravel requiere un token CSRF en formularios POST para evitar ataques.

-   Se agrega con @csrf dentro del formulario Blade.

-   Si se omite, se genera un error 419 (Página Expirada).

---

#### 🗃 Creación de Registros

-   Utiliza Eloquent para crear un nuevo registro.

-   Después de guardar el nuevo trabajo, redirige al listado.

```php
Route::post('/jobs', function () {
    Job::create([
        'title' => request('title'),
        'salary' => request('salary'),
        'employer_id' => 1
    ]);

    return redirect('/jobs');
});
```

## 🎬 Episodio 17 - Always Validate. Never Trust the User.

### 🎯 Resumen del Episodio

En este episodio se abordan las mejores prácticas para validar formularios en Laravel, tanto del lado del servidor como del cliente, y se muestra cómo manejar errores de forma amigable.

---

### ✅ Cambios clave:

#### ➕ Agregar Botón "Create Job"

-   Se añade un botón en el layout para crear un nuevo trabajo:

```blade
<a href="/jobs/create" class="bg-blue-500 text-white px-4 py-2 rounded">Create Job</a>
```

---

#### ✅ Validación del Lado del Servidor

-   Laravel incluye validación integrada::

```php
Route::post('/jobs', function () {
    request()->validate([
        'title' => ['required', 'min:3'],
        'salary' => ['required']
    ]);

    Job::create([
        'title' => request('title'),
        'salary' => request('salary'),
        'employer_id' => 1
    ]);

    return redirect('/jobs');
});
```

---

#### 🔍 Mostrar Errores en la Vista

Globalmente:

```blade
@if ($errors->any())
    <ul>
        @foreach ($errors->all() as $error)
            <li class="text-red-500">{{ $error }}</li>
        @endforeach
    </ul>
@endif
```

Errores específicos bajo cada input:

```blade
@error('title')
    <p class="text-red-500 text-sm">{{ $message }}</p>
@enderror
```

---

#### 🧪 Validación del Lado del Cliente

-   Agrega `required` a los campos HTML:

```html
<input type="text" name="title" required />
```

## 🎬 Episodio 18 - Editing, Updating, and Deleting a Resource

### 🎯 Resumen del Episodio

En este episodio se completan las operaciones básicas de CRUD en Laravel, añadiendo la funcionalidad para editar, actualizar y eliminar registros del recurso `jobs`.

---

### ✅ Cambios clave:

#### 📝 Agregar Botón "Edit Job"

En la vista `show.blade.php`, se agregó un botón para editar un trabajo:

```blade
<a href="/jobs/{{ $job->id }}/edit" class="bg-yellow-500 text-white px-4 py-2 rounded">Edit Job</a>
```

---

#### 🛠 Ruta y Vista para Editar

Se define la ruta `GET /jobs/{id}/edit` para mostrar el formulario de edición:

```php
Route::get('/jobs/{id}/edit', function ($id) {
    $job = Job::findOrFail($id);
    return view('jobs.edit', ['job' => $job]);
});
```

Se crea la vista `resources/views/jobs/edit.blade.php`, similar al formulario de creación pero con los campos precargados:

```blade
<input type="text" name="title" value="{{ old('title', $job->title) }}" required>
<input type="number" name="salary" value="{{ old('salary', $job->salary) }}" required>
```

---

#### 🔁 Ruta para Actualizar

Se utiliza `PATCH` para actualizar un recurso existente:

```php
use Illuminate\Http\Request;

Route::patch('/jobs/{id}', function (Request $request, $id) {
    $request->validate([
        'title' => 'required|min:3',
        'salary' => 'required',
    ]);

    $job = Job::findOrFail($id);
    $job->update([
        'title' => $request->input('title'),
        'salary' => $request->input('salary'),
    ]);

    return redirect("/jobs/{$id}");
});
```

En el formulario Blade, se añade el método HTTP `PATCH` con la directiva:

```blade
@method('PATCH')
@csrf
```

---

#### 🗑 Ruta para Eliminar

Para eliminar un trabajo, se define una ruta `DELETE`:

```php
Route::delete('/jobs/{id}', function ($id) {
    $job = Job::findOrFail($id);
    $job->delete();

    return redirect('/jobs');
});
```

Debido a que los formularios no pueden ser anidados, se utiliza un formulario oculto con un botón que lo activa:

```blade
<form id="delete-job-{{ $job->id }}" action="/jobs/{{ $job->id }}" method="POST">
    @csrf
    @method('DELETE')
</form>

<button form="delete-job-{{ $job->id }}" class="bg-red-500 text-white px-4 py-2 rounded">
    Delete Job
</button>
```

## 🎬 Episodio 19 - Routes Reloaded - 6 Essential Tips

### 🎯 Resumen del Episodio

En este episodio se mejoró la organización del archivo de rutas (`web.php`) aplicando buenas prácticas como el uso de Route Model Binding, controladores dedicados y rutas agrupadas o declarativas.

---

### ✅ Cambios clave:

#### 🔗 1. Route Model Binding

Se reemplazaron las rutas con `id` por rutas que automáticamente resuelven el modelo:

Antes:

```php
Route::get('/jobs/{id}', function ($id) {
    $job = Job::findOrFail($id);
    return view('jobs.show', ['job' => $job]);
});
```

Después (con model binding):

```php
use App\Models\Job;

Route::get('/jobs/{job}', function (Job $job) {
    return view('jobs.show', ['job' => $job]);
});
```

-   💡 El nombre del parámetro en la URL (`{job}`) debe coincidir con el nombre del parámetro en el callback (`Job $job`).

---

#### 🎮 2. Uso de Controladores Dedicados

Se creó un controlador para manejar la lógica de los trabajos:

```bash
php artisan make:controller JobController
```

Se movió la lógica de las rutas al controlador `JobController` usando métodos como:

```php
public function index() { ... }
public function show(Job $job) { ... }
public function create() { ... }
// etc.
```

Y se actualizaron las rutas para apuntar al controlador:

```php
use App\Http\Controllers\JobController;

Route::get('/jobs', [JobController::class, 'index']);
Route::get('/jobs/{job}', [JobController::class, 'show']);
```

---

#### 📋 3. Listado de Rutas

Puedes listar todas las rutas de tu aplicación con:

```bash
php artisan route:list
```

Para enfocarte solo en las rutas de tu app, puedes excluir las del core de Laravel:

```bash
php artisan route:list --except=vendor
```

---

#### 🔁 4. Declarar Rutas con Route::resource

Laravel ofrece una forma más limpia de registrar todas las rutas CRUD estándar:

```php
Route::resource('jobs', JobController::class);
```

## 🎬 Episodio 20 - Starter Kits, Breeze y Middleware

### 🎯 Resumen del Episodio

En este episodio se introdujo el uso de Laravel Breeze, un kit de inicio oficial que permite añadir autenticación básica de forma rápida a tu proyecto Laravel. También se exploró cómo funciona el middleware para proteger rutas.

---

### 🚀 ¿Qué es Laravel Breeze?

Laravel Breeze es un kit de inicio liviano que incluye:

-   Formularios de registro y login

-   Página de dashboard protegida

-   Gestión de perfil y actualización de contraseña

-   Funcionalidad de logout

-   Middleware para restringir acceso a rutas

---

### ✅ Cómo instalar Laravel Breeze

```bash
laravel new nombre-del-proyecto
```

Durante el proceso de instalación, selecciona `Breeze` como starter kit. Esto sobrescribirá algunas rutas, vistas y componentes por defecto.

Después de instalar, ejecuta el servidor:

```bash
php artisan serve
```

---

### 📦 ¿Qué incluye Breeze?

-   Blade + Tailwind por defecto (también puedes elegir Vue, React o Livewire).

-   Vistas preconstruidas para login, registro, dashboard y perfil.

-   Componentes Blade reutilizables para formularios, inputs, validación, errores, etc.

-   Middleware auth aplicado a rutas protegidas.

---

### 🔐 Middleware de Autenticación

El middleware actúa como una capa de seguridad entre el navegador y la lógica de tu aplicación.

Laravel incluye middleware como:

-   auth → Requiere que el usuario esté autenticado.

-   verified → Asegura que el usuario haya verificado su email.

Ejemplo de cómo proteger una ruta:

```php
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified']);
```

---

### 👤 Acceder al Usuario Autenticado

Puedes acceder al usuario autenticado con:

```php
use Illuminate\Support\Facades\Auth;

$user = Auth::user();
```

O usando el helper:

```php
$user = auth()->user();
```

---

### 🛠 Registro de Usuario con Validación

Breeze implementa todo lo siguiente:

-   Validación de datos

-   Hash de la contraseña

-   Evento Registered

-   Inicio de sesión automático

## 🎬 Episodio 21 - Make a Login and Registration System From Scratch: Part 1

### 🎯 Resumen del Episodio

En este episodio comenzamos a construir manualmente un sistema de autenticación (registro e inicio de sesión) sin utilizar kits como Breeze. Se reutilizan componentes de formularios y se organizan las rutas y controladores necesarios.

---

### ✅ Cambios clave:

#### 🧱 Componentes Reutilizables de Blade

Se crean componentes para mantener los formularios limpios y reutilizables:

-   `resources/views/components/form-label.blade.php`

```blade
<label {{ $attributes->merge(['class' => 'block font-medium text-sm text-gray-700']) }}>
    {{ $slot }}
</label>
```

-   `resources/views/components/form-error.blade.php`

```blade
@props(['name'])

@error($name)
    <p class="text-sm text-red-500 mt-1">{{ $message }}</p>
@enderror
```

-   `resources/views/components/form-input.blade.php`

```blade
@props(['disabled' => false])

<input {{ $disabled ? 'disabled' : '' }} {!! $attributes->merge(['class' => 'border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm']) !!}>
```

---

#### 📝 Formularios de Registro e Inicio de Sesión

Se crean las vistas:

-   `resources/views/auth/register.blade.php`

-   `resources/views/auth/login.blade.php`

Usando los componentes:

```blade
<x-form-label for="email">Email</x-form-label>
<x-form-input id="email" name="email" type="email" required />
<x-form-error name="email" />
```

---

#### 🧭 Rutas de Autenticación

En `routes/web.php` se definen:

```php
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\Auth\SessionController;

Route::get('/register', [RegisteredUserController::class, 'create'])->middleware('guest');
Route::post('/register', [RegisteredUserController::class, 'store'])->middleware('guest');

Route::get('/login', [SessionController::class, 'create'])->middleware('guest');
Route::post('/login', [SessionController::class, 'store'])->middleware('guest');
```

#### 🧑‍💻 Controladores de Autenticación

Se crean los controladores:

```php
namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class RegisteredUserController extends Controller
{
    public function create()
    {
        return view('auth.register');
    }

    public function store(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:8|confirmed',
        ]);

        User::create([
            'first_name' => $request->input('first_name'),
            'last_name'  => $request->input('last_name'),
            'email'      => $request->input('email'),
            'password'   => Hash::make($request->input('password')),
        ]);

        return redirect('/login');
    }
}
```

## 🎬 Episodio 22 - Make a Login and Registration System From Scratch: Part 2

### 🎯 Resumen del Episodio

Continuamos la implementación manual de registro e inicio de sesión en Laravel, enfocándonos ahora en la lógica detrás del registro y login.

---

### ✅ Cambios clave:

#### 📝 Proceso de Registro

##### 1. Validación de Datos

Se utiliza $request->validate() para asegurar que los campos requeridos cumplan con las reglas:

```php
use Illuminate\Validation\Rules\Password;

$attributes = $request->validate([
    'first_name' => ['required', 'min:1'],
    'last_name' => ['required', 'min:1'],
    'email' => ['required', 'email', 'unique:users'],
    'password' => ['required', 'confirmed', Password::min(6)],
]);
```

-   🔐 `confirmed` requiere que el campo `password_confirmation` esté presente y coincida.

##### 2. Creación del Usuario

```php
$user = User::create($attributes);
```

##### 3. Inicio de Sesión Automático

```php
Auth::login($user);
```

##### 4. Redirección Post-Registro

```php
return redirect('/jobs');
```

---

### 🔐 Hash de Contraseñas

Laravel hashea automáticamente la contraseña si configuras el modelo correctamente:

```php
// En User.php
protected $casts = [
    'password' => 'hashed',
];
```

---

### 🔑 Proceso de Inicio de Sesión

#### 1. Validación de Entrada

```php
$credentials = $request->validate([
    'email' => ['required', 'email'],
    'password' => ['required'],
]);
```

#### 2. Intento de Autenticación

```php
if (Auth::attempt($credentials)) {
    $request->session()->regenerate(); // Protección contra ataques de sesión
    return redirect()->intended('/jobs');
}
```

#### 3. Manejo de Fallos

```php
throw ValidationException::withMessages([
    'email' => 'Las credenciales no coinciden con nuestros registros.',
]);
```

---

### 🧠 Mantener Valores del Formulario

Para no perder los valores del formulario tras un error de validación:

```blade
<x-form-input name="email" :value="old('email')" />
```

Usa `old('campo')` para recuperar el valor previo enviado por el usuario.

## 🎬 Episodio 23 - 6 Steps to Authorization Mastery

### 🎯 Resumen del Episodio

Hoy nos enfocamos en autorización en Laravel: cómo asegurarte de que solo usuarios autorizados puedan realizar ciertas acciones como editar o eliminar un recurso.

---

### ✅ Cambios clave:

#### 🥇 Paso 1: Establecer Relaciones entre Modelos

Para permitir autorizaciones basadas en usuarios:

-   Añade una columna `user_id` a la tabla employers.

-   Actualiza la factory de Employer para que cree un usuario relacionado:

```php
'user_id' => User::factory(),
```

Esto conecta un `Job` con un `User` a través de Employer.

---

#### 🥈 Paso 2: Autorización Inline en el Controlador

Dentro del método edit del controlador:

```php
if (auth()->guest()) {
    return redirect('/login');
}

if (auth()->user()->id !== $job->employer->user_id) {
    abort(403);
}
```

💡 Usa is() para comparar modelos:

```php
if (! auth()->user()->is($job->employer->user)) {
    abort(403);
}
```

---

#### 🥉 Paso 3: Usar Gates

Extrae la lógica de autorización a **gates**:

1. Define el gate en `App\Providers\AuthServiceProvider`:

```php
use Illuminate\Support\Facades\Gate;

Gate::define('edit-job', function (User $user, Job $job) {
    return $user->is($job->employer->user);
});
```

2. Utilízalo en el controlador:

```php
Gate::authorize('edit-job', $job);
```

✅ Lanza `403` automáticamente si falla la autorización.

---

#### 🏅 Paso 4: Métodos can y cannot

El modelo User tiene métodos para verificar permisos:

```blade
@can('edit-job', $job)
    <a href="/jobs/{{ $job->id }}/edit">Editar</a>
@endcan
```

También puedes usarlo en controladores:

```php
if ($user->cannot('edit-job', $job)) {
    abort(403);
}
```

---

#### 🏆 Paso 5: Middleware de Autorización

Protege rutas directamente con middleware:

```php
Route::patch('/jobs/{job}', [JobController::class, 'update'])
    ->middleware(['auth', 'can:edit-job,job']);
```

Esto asegura que el usuario esté autenticado y autorizado antes de ejecutar el método.

---

#### 🎖 Paso 6: Políticas

Para un sistema robusto y escalable, usa políticas:

1. Crear una política:

```bash
php artisan make:policy JobPolicy --model=Job
```

2. Definir métodos como `edit`, `update`, `delete`, etc.

3. Registrar la política en `AuthServiceProvider`:

```php
protected $policies = [
    Job::class => JobPolicy::class,
];
```

4. Usar en controladores o Blade:

```php
$this->authorize('edit', $job);
```

```blade
@can('edit', $job)
```

## 🎬 Episodio 24 - How to Preview and Send Email Using Mailable Classes

### 🎯 Resumen del Episodio

En este episodio se explicó cómo enviar correos electrónicos en Laravel utilizando las clases **Mailable**, que permiten estructurar y visualizar mensajes de manera clara y reutilizable.

---

### ✅ Cambios clave:

#### 🛠️ Generar una clase Mailable

Se creó una clase `JobPosted` con:

```bash
php artisan make:mail JobPosted
```

Esto genera el archivo app/Mail/JobPosted.php, donde se pueden configurar:

-   Envelope: asunto, remitente, respuesta, etiquetas.

-   Content: la vista Blade que representará el cuerpo del mensaje.

-   Attachments: archivos adjuntos (opcional).

---

#### 🧾 Crear la vista de correo

Se añadió una vista sencilla en `resources/views/mail/job-posted.blade.php`:

```blade
<p>Congrats, your job is now live on our website.</p>
```

---

#### 👀 Previsualizar el correo en el navegador

Ruta temporal para ver el contenido renderizado del correo:

```php
Route::get('/test', function () {
    return new \App\Mail\JobPosted();
});
```

---

#### ✉️ Enviar correos

Usando la fachada `Mail`:

```php
use Illuminate\Support\Facades\Mail;

Mail::to('jeffrey@laracasts.com')->send(new \App\Mail\JobPosted());
```

---

#### ⚙️ Configurar el envío de correos

En `.env` o `config/mail.php`, configurar tu proveedor SMTP (ej. Mailtrap):

```env
MAIL_MAILER=smtp
MAIL_HOST=sandbox.mailtrap.io
MAIL_PORT=2525
MAIL_USERNAME=your_username
MAIL_PASSWORD=your_password
MAIL_FROM_ADDRESS=info@laracasts.com
MAIL_FROM_NAME="Laracasts"
MAIL_ENCRYPTION=null
```

---

#### 🔗 Generar URLs dentro del correo

Usa el helper url() para construir rutas absolutas:

```blade
<a href="{{ url('jobs/' . $job->id) }}">View your job listing</a>
```

## 🧵 Episodio 25 - Queues Are Easier Than You Think

### 🎯 Resumen del Episodio

En este episodio se abordó el uso de **colas (queues)** en Laravel para ejecutar tareas pesadas (como enviar correos) en segundo plano, mejorando el tiempo de respuesta para el usuario.

---

### ✅ Cambios clave:

#### ⚙️ Configuración de Queues

Laravel soporta múltiples **drivers de cola**:

-   `sync`: Ejecuta trabajos de inmediato (por defecto).
-   `database`: Almacena trabajos en la base de datos.
-   `beanstalkd`, `SQS`, `Redis`: Otras opciones más avanzadas.

Ejemplo en `.env`:

```env
QUEUE_CONNECTION=database
```

---

#### ✉️ Enviar correos en background

En lugar de enviar correos directamente:

```php
Mail::to($user)->send(new JobPosted($job));
```

Usamos el método `queue` para enviarlo en segundo plano:

```php
Mail::to($user)->queue(new JobPosted($job));
```

Esto delega el envío a una cola.

---

#### ▶️ Ejecutar el worker de la cola

Para procesar trabajos en cola:

```bash
php artisan queue:work
```

El worker escucha y ejecuta los trabajos pendientes.

---

#### 🔁 Dispatch de Closures

También puedes enviar closures directamente a la cola:

```php
dispatch(function () {
    Log::info('Hello from the queue');
})->delay(now()->addSeconds(5));
```

Esto retrasa su ejecución 5 segundos.

---

#### 🧱 Crear Jobs personalizados

Para lógica compleja, crea clases de trabajo:

```bash
php artisan make:job TranslateJob
```

Define la lógica en `handle()`:

```php
public function handle(): void
{
logger('Translating ' . $this->jobListing->title . ' to Spanish.');
}
```

Despacha el trabajo con:

```php
TranslateJob::dispatch($jobListing);
```

-   ⚠️ Recuerda reiniciar el worker si modificas código:

```bash
php artisan queue:restart
```

## 🛠️ Episodio 26 - Get Your Build Process in Order

### 🎯 Resumen del Episodio

En este episodio se exploró cómo **gestionar los assets frontend** (CSS, JS, imágenes) en Laravel utilizando **Vite**, optimizando su rendimiento para producción.

---

### ✅ Cambios clave:

#### 📦 ¿Qué es el Asset Bundling?

**Asset bundling** es el proceso de:

-   Combinar archivos.
-   Minificarlos y comprimirlos.
-   Mejorar el rendimiento de carga.

---

#### ⚡ Laravel + Vite

Laravel integra **Vite** de forma nativa.

Tu `package.json` ya incluye dependencias como:

```json
"devDependencies": {
  "vite": "^x.x.x",
  "@vitejs/plugin-vue": "^x.x.x",
  // ...
}
```

---

#### ⚙️ Configuración de Vite

El archivo `vite.config.js` define los puntos de entrada de tus assets (por defecto en `resources/`).

---

### 🚀 Ejecutar Vite

Usa los siguientes scripts:

```bash
npm run dev # Para desarrollo con recarga en caliente (HMR)
```

```bash
npm run build # Para compilar y optimizar para producción
```

---

#### 🧩 Incluir Assets en Blade

Agrega tus assets con la directiva `@vite`:

```blade
@vite(['resources/css/app.css', 'resources/js/app.js'])
```

Esto asegura que los archivos se enlacen correctamente tanto en desarrollo como producción.

---

#### 🎨 Tailwind CSS con Vite

En lugar del CDN, instala Tailwind por npm:

```bash
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init
```

Edita `tailwind.config.js` para incluir tus paths Blade:

```js
content: ["./resources/**/*.blade.php", "./resources/**/*.js"];
```

Agrega las directivas a tu CSS:

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```
